# Phần mềm quản lý sinh viên (Java Swing + SQL Server)

Đồ án phần mềm Java. Chức năng: **thêm, sửa, xóa, tìm kiếm** cho 5 danh mục: sinh viên, lớp, khoa, môn học, điểm.

## Cấu trúc
- `sql/QuanLySinhVien.sql`: script tạo CSDL, bảng, ràng buộc và dữ liệu mẫu.
- `src/main/java/qlsv/`: mã nguồn
  - `Main`: khởi chạy, kiểm tra kết nối
  - `Db`: kết nối SQL Server và các hàm truy vấn (JDBC)
  - `BaseForm`: khung chung của các form quản lý
  - `MainForm` (menu), `SinhVienForm`, `LopForm`, `KhoaForm`, `MonHocForm`, `DiemForm`

## Cách chạy
1. Mở SQL Server Management Studio, chạy file `sql/QuanLySinhVien.sql` (chỉ chạy một lần).
2. Bật SQL Server Authentication (Mixed Mode), bật TCP/IP cổng 1433 trong SQL Server Configuration Manager.
3. Mở `src/main/java/qlsv/Db.java`, sửa `HOST`, `PORT`, `USER`, `PASSWORD` cho đúng máy của bạn.
4. Mở thư mục này bằng NetBeans / IntelliJ / Eclipse như một **Maven project** (tự tải thư viện `mssql-jdbc`), rồi chạy lớp `qlsv.Main`.
   Hoặc dùng dòng lệnh: `mvn compile exec:java -Dexec.mainClass=qlsv.Main`

## Đưa lên GitHub
```
git init
git add .
git commit -m "Do an Java - Quan ly sinh vien"
git branch -M main
git remote add origin https://github.com/<ten-tai-khoan>/QuanLySinhVien.git
git push -u origin main
```
Sau đó gửi link repository lên hệ thống nộp bài.
