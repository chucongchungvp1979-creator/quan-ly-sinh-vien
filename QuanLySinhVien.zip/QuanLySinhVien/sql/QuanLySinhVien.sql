-- Chạy script này MỘT LẦN trong SQL Server Management Studio để tạo CSDL và dữ liệu mẫu.

CREATE DATABASE QuanLySinhVien;
GO
USE QuanLySinhVien;
GO

CREATE TABLE Khoa (
    MaKhoa  VARCHAR(10)   NOT NULL,
    TenKhoa NVARCHAR(100) NOT NULL,
    CONSTRAINT PK_Khoa PRIMARY KEY (MaKhoa),
    CONSTRAINT UQ_Khoa_TenKhoa UNIQUE (TenKhoa)
);

CREATE TABLE Lop (
    MaLop  VARCHAR(10)  NOT NULL,
    TenLop NVARCHAR(50) NOT NULL,
    MaKhoa VARCHAR(10)  NOT NULL,
    CONSTRAINT PK_Lop PRIMARY KEY (MaLop),
    CONSTRAINT FK_Lop_Khoa FOREIGN KEY (MaKhoa)
        REFERENCES Khoa(MaKhoa)
);

CREATE TABLE SinhVien (
    MaSV     VARCHAR(15)   NOT NULL,
    HoTen    NVARCHAR(100) NOT NULL,
    NgaySinh DATE          NOT NULL,
    GioiTinh NVARCHAR(5),
    DiaChi   NVARCHAR(200),
    SDT      VARCHAR(11),
    MaLop    VARCHAR(10)   NOT NULL,
    CONSTRAINT PK_SinhVien PRIMARY KEY (MaSV),
    CONSTRAINT UQ_SinhVien_SDT UNIQUE (SDT),
    CONSTRAINT CK_SinhVien_GioiTinh
        CHECK (GioiTinh IN (N'Nam', N'Nữ')),
    CONSTRAINT FK_SinhVien_Lop FOREIGN KEY (MaLop)
        REFERENCES Lop(MaLop)
);

CREATE TABLE MonHoc (
    MaMH     VARCHAR(10)   NOT NULL,
    TenMH    NVARCHAR(100) NOT NULL,
    SoTinChi INT           NOT NULL,
    CONSTRAINT PK_MonHoc PRIMARY KEY (MaMH),
    CONSTRAINT CK_MonHoc_SoTinChi
        CHECK (SoTinChi BETWEEN 1 AND 10)
);

CREATE TABLE Diem (
    MaSV          VARCHAR(15) NOT NULL,
    MaMH          VARCHAR(10) NOT NULL,
    DiemChuyenCan FLOAT,
    DiemThi       FLOAT,
    DiemTongKet AS (0.3 * DiemChuyenCan + 0.7 * DiemThi),
    CONSTRAINT PK_Diem PRIMARY KEY (MaSV, MaMH),
    CONSTRAINT FK_Diem_SinhVien FOREIGN KEY (MaSV)
        REFERENCES SinhVien(MaSV),
    CONSTRAINT FK_Diem_MonHoc FOREIGN KEY (MaMH)
        REFERENCES MonHoc(MaMH),
    CONSTRAINT CK_Diem_ChuyenCan
        CHECK (DiemChuyenCan BETWEEN 0 AND 10),
    CONSTRAINT CK_Diem_Thi
        CHECK (DiemThi BETWEEN 0 AND 10)
);
GO

-- Dữ liệu mẫu
USE QuanLySinhVien;
GO
INSERT INTO Khoa VALUES ('CNTT', N'Công nghệ thông tin');
INSERT INTO Khoa VALUES ('KT', N'Kinh tế');

INSERT INTO Lop VALUES ('TH30.1', N'Tin học 30.1', 'CNTT');
INSERT INTO Lop VALUES ('TH30.2', N'Tin học 30.2', 'CNTT');
INSERT INTO Lop VALUES ('KT30.1', N'Kinh tế 30.1', 'KT');

INSERT INTO SinhVien VALUES ('SV001', N'Nguyễn Văn An', '2005-03-12', N'Nam', N'Hà Nội', '0901000001', 'TH30.1');
INSERT INTO SinhVien VALUES ('SV002', N'Trần Thị Bình', '2005-07-25', N'Nữ', N'Hải Phòng', '0901000002', 'TH30.1');
INSERT INTO SinhVien VALUES ('SV003', N'Lê Minh Cường', '2005-11-02', N'Nam', N'Nam Định', '0901000003', 'TH30.2');
INSERT INTO SinhVien VALUES ('SV004', N'Phạm Thu Dung', '2005-01-18', N'Nữ', N'Hà Nội', '0901000004', 'KT30.1');

INSERT INTO MonHoc VALUES ('JAVA', N'Lập trình Java', 3);
INSERT INTO MonHoc VALUES ('CSDL', N'Cơ sở dữ liệu', 3);
INSERT INTO MonHoc VALUES ('MAC', N'Triết học Mác - Lênin', 2);

INSERT INTO Diem (MaSV, MaMH, DiemChuyenCan, DiemThi) VALUES ('SV001', 'JAVA', 9, 8);
INSERT INTO Diem (MaSV, MaMH, DiemChuyenCan, DiemThi) VALUES ('SV001', 'CSDL', 8, 7.5);
INSERT INTO Diem (MaSV, MaMH, DiemChuyenCan, DiemThi) VALUES ('SV002', 'JAVA', 10, 9);
INSERT INTO Diem (MaSV, MaMH, DiemChuyenCan, DiemThi) VALUES ('SV003', 'CSDL', 7, 6.5);
INSERT INTO Diem (MaSV, MaMH, DiemChuyenCan, DiemThi) VALUES ('SV004', 'MAC', 9, 8.5);
GO
