package qlsv;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;

/** Form: Quản lý lớp. */
public class LopForm extends BaseForm {
    private final JTextField txtMa = new JTextField();
    private final JTextField txtTen = new JTextField();
    private final JComboBox<Db.Item> cboKhoa = new JComboBox<>();

    public LopForm() {
        super("Quản lý lớp", 700, 520);
        addField("Mã lớp:", txtMa);
        addField("Tên lớp:", txtTen);
        addField("Khoa:", cboKhoa);
        try {
            Db.fillCombo(cboKhoa, "SELECT MaKhoa, TenKhoa FROM Khoa ORDER BY MaKhoa");
        } catch (SQLException ex) {
            loi(ex);
        }
        build();
    }

    @Override
    protected DefaultTableModel layDuLieu(String kw) throws SQLException {
        String k = "%" + kw + "%";
        return Db.query("SELECT l.MaLop AS [Mã lớp], l.TenLop AS [Tên lớp], "
                + "k.TenKhoa AS [Khoa], l.MaKhoa AS [Mã khoa] "
                + "FROM Lop l JOIN Khoa k ON l.MaKhoa = k.MaKhoa "
                + "WHERE l.MaLop LIKE ? OR l.TenLop LIKE ? OR k.TenKhoa LIKE ? "
                + "ORDER BY l.MaLop", k, k, k);
    }

    @Override
    protected void hienThiDong(int r) {
        txtMa.setText(cell(r, 0));
        txtTen.setText(cell(r, 1));
        Db.select(cboKhoa, cell(r, 3));
    }

    @Override
    protected void lamMoi() {
        txtMa.setText("");
        txtTen.setText("");
        if (cboKhoa.getItemCount() > 0) {
            cboKhoa.setSelectedIndex(0);
        }
        table.clearSelection();
    }

    @Override
    protected void them() throws SQLException {
        Db.update("INSERT INTO Lop(MaLop, TenLop, MaKhoa) VALUES (?, ?, ?)",
                bat(txtMa, "Mã lớp"), bat(txtTen, "Tên lớp"), Db.idOf(cboKhoa));
    }

    @Override
    protected void sua() throws SQLException {
        int n = Db.update("UPDATE Lop SET TenLop = ?, MaKhoa = ? WHERE MaLop = ?",
                bat(txtTen, "Tên lớp"), Db.idOf(cboKhoa), bat(txtMa, "Mã lớp"));
        kiemTraCoDong(n, "sửa");
    }

    @Override
    protected void xoa() throws SQLException {
        int n = Db.update("DELETE FROM Lop WHERE MaLop = ?", bat(txtMa, "Mã lớp"));
        kiemTraCoDong(n, "xóa");
    }
}
