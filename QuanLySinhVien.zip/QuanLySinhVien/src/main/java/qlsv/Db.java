package qlsv;

import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Vector;

/** Lớp tiện ích kết nối và thao tác với SQL Server (JDBC). */
public class Db {

    // ====== CẤU HÌNH KẾT NỐI: sửa lại cho đúng với máy của bạn ======
    private static final String HOST = "localhost";
    private static final String PORT = "1433";
    private static final String DATABASE = "QuanLySinhVien";
    private static final String USER = "sa";
    private static final String PASSWORD = "123456";
    // =================================================================

    private static final String URL = "jdbc:sqlserver://" + HOST + ":" + PORT
            + ";databaseName=" + DATABASE
            + ";encrypt=true;trustServerCertificate=true;";

    /** Một mục trong ComboBox: id dùng để lưu CSDL, label dùng để hiển thị. */
    public static class Item {
        public final String id;
        public final String label;

        public Item(String id, String label) {
            this.id = id;
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private static void bind(PreparedStatement ps, Object[] params) throws SQLException {
        for (int i = 0; i < params.length; i++) {
            if (params[i] == null) {
                ps.setNull(i + 1, Types.NVARCHAR);
            } else {
                ps.setObject(i + 1, params[i]);
            }
        }
    }

    /** Chạy câu SELECT và trả về model cho JTable (không cho sửa trực tiếp trên bảng). */
    public static DefaultTableModel query(String sql, Object... params) throws SQLException {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData md = rs.getMetaData();
                int n = md.getColumnCount();
                Vector<String> cols = new Vector<>();
                for (int i = 1; i <= n; i++) {
                    cols.add(md.getColumnLabel(i));
                }
                Vector<Vector<Object>> rows = new Vector<>();
                while (rs.next()) {
                    Vector<Object> r = new Vector<>();
                    for (int i = 1; i <= n; i++) {
                        r.add(rs.getObject(i));
                    }
                    rows.add(r);
                }
                return new DefaultTableModel(rows, cols) {
                    @Override
                    public boolean isCellEditable(int row, int col) {
                        return false;
                    }
                };
            }
        }
    }

    /** Chạy INSERT / UPDATE / DELETE, trả về số dòng bị ảnh hưởng. */
    public static int update(String sql, Object... params) throws SQLException {
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, params);
            return ps.executeUpdate();
        }
    }

    /** Nạp dữ liệu cho ComboBox. Câu SELECT phải trả về 2 cột: id, nhãn hiển thị. */
    public static void fillCombo(JComboBox<Item> cb, String sql) throws SQLException {
        cb.removeAllItems();
        try (Connection c = getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                cb.addItem(new Item(rs.getString(1), rs.getString(2)));
            }
        }
    }

    /** Lấy id của mục đang chọn trong ComboBox. */
    public static String idOf(JComboBox<Item> cb) {
        Item it = (Item) cb.getSelectedItem();
        if (it == null) {
            throw new IllegalArgumentException("Vui lòng chọn một mục trong danh sách.");
        }
        return it.id;
    }

    /** Chọn mục có id tương ứng trong ComboBox. */
    public static void select(JComboBox<Item> cb, String id) {
        for (int i = 0; i < cb.getItemCount(); i++) {
            if (cb.getItemAt(i).id.equals(id)) {
                cb.setSelectedIndex(i);
                return;
            }
        }
    }
}
