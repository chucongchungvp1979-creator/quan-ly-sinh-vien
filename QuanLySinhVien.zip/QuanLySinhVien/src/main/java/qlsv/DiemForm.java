package qlsv;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;

/** Form: Quản lý điểm (điểm tổng kết = 30% chuyên cần + 70% điểm thi, tính tự động trong CSDL). */
public class DiemForm extends BaseForm {
    private final JComboBox<Db.Item> cboSV = new JComboBox<>();
    private final JComboBox<Db.Item> cboMH = new JComboBox<>();
    private final JTextField txtCC = new JTextField();
    private final JTextField txtThi = new JTextField();

    public DiemForm() {
        super("Quản lý điểm", 950, 560);
        addField("Sinh viên:", cboSV);
        addField("Môn học:", cboMH);
        addField("Điểm chuyên cần (0 - 10):", txtCC);
        addField("Điểm thi (0 - 10):", txtThi);
        try {
            Db.fillCombo(cboSV, "SELECT MaSV, MaSV + N' - ' + HoTen FROM SinhVien ORDER BY MaSV");
            Db.fillCombo(cboMH, "SELECT MaMH, MaMH + N' - ' + TenMH FROM MonHoc ORDER BY MaMH");
        } catch (SQLException ex) {
            loi(ex);
        }
        build();
    }

    @Override
    protected DefaultTableModel layDuLieu(String kw) throws SQLException {
        String k = "%" + kw + "%";
        return Db.query("SELECT d.MaSV AS [Mã SV], sv.HoTen AS [Họ tên], d.MaMH AS [Mã MH], "
                + "mh.TenMH AS [Môn học], d.DiemChuyenCan AS [Điểm CC], d.DiemThi AS [Điểm thi], "
                + "ROUND(d.DiemTongKet, 2) AS [Điểm TK] "
                + "FROM Diem d JOIN SinhVien sv ON d.MaSV = sv.MaSV JOIN MonHoc mh ON d.MaMH = mh.MaMH "
                + "WHERE d.MaSV LIKE ? OR sv.HoTen LIKE ? OR d.MaMH LIKE ? OR mh.TenMH LIKE ? "
                + "ORDER BY d.MaSV, d.MaMH", k, k, k, k);
    }

    @Override
    protected void hienThiDong(int r) {
        Db.select(cboSV, cell(r, 0));
        Db.select(cboMH, cell(r, 2));
        txtCC.setText(cell(r, 4));
        txtThi.setText(cell(r, 5));
    }

    @Override
    protected void lamMoi() {
        if (cboSV.getItemCount() > 0) {
            cboSV.setSelectedIndex(0);
        }
        if (cboMH.getItemCount() > 0) {
            cboMH.setSelectedIndex(0);
        }
        txtCC.setText("");
        txtThi.setText("");
        table.clearSelection();
    }

    private double docDiem(JTextField t, String ten) {
        double d = Double.parseDouble(bat(t, ten).replace(',', '.'));
        if (d < 0 || d > 10) {
            throw new IllegalArgumentException(ten + " phải nằm trong khoảng 0 đến 10.");
        }
        return d;
    }

    @Override
    protected void them() throws SQLException {
        Db.update("INSERT INTO Diem(MaSV, MaMH, DiemChuyenCan, DiemThi) VALUES (?, ?, ?, ?)",
                Db.idOf(cboSV), Db.idOf(cboMH),
                docDiem(txtCC, "Điểm chuyên cần"), docDiem(txtThi, "Điểm thi"));
    }

    @Override
    protected void sua() throws SQLException {
        int n = Db.update("UPDATE Diem SET DiemChuyenCan = ?, DiemThi = ? WHERE MaSV = ? AND MaMH = ?",
                docDiem(txtCC, "Điểm chuyên cần"), docDiem(txtThi, "Điểm thi"),
                Db.idOf(cboSV), Db.idOf(cboMH));
        kiemTraCoDong(n, "sửa");
    }

    @Override
    protected void xoa() throws SQLException {
        int n = Db.update("DELETE FROM Diem WHERE MaSV = ? AND MaMH = ?",
                Db.idOf(cboSV), Db.idOf(cboMH));
        kiemTraCoDong(n, "xóa");
    }
}
