package qlsv;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;

/** Form: Quản lý sinh viên. */
public class SinhVienForm extends BaseForm {
    private final JTextField txtMa = new JTextField();
    private final JTextField txtTen = new JTextField();
    private final JTextField txtNgaySinh = new JTextField();
    private final JComboBox<String> cboGioiTinh = new JComboBox<>(new String[]{"Nam", "Nữ"});
    private final JTextField txtDiaChi = new JTextField();
    private final JTextField txtSdt = new JTextField();
    private final JComboBox<Db.Item> cboLop = new JComboBox<>();

    public SinhVienForm() {
        super("Quản lý sinh viên", 950, 620);
        addField("Mã sinh viên:", txtMa);
        addField("Họ và tên:", txtTen);
        addField("Ngày sinh (yyyy-MM-dd):", txtNgaySinh);
        addField("Giới tính:", cboGioiTinh);
        addField("Địa chỉ:", txtDiaChi);
        addField("Số điện thoại:", txtSdt);
        addField("Lớp:", cboLop);
        try {
            Db.fillCombo(cboLop, "SELECT MaLop, MaLop + N' - ' + TenLop FROM Lop ORDER BY MaLop");
        } catch (SQLException ex) {
            loi(ex);
        }
        build();
    }

    @Override
    protected DefaultTableModel layDuLieu(String kw) throws SQLException {
        String k = "%" + kw + "%";
        return Db.query("SELECT sv.MaSV AS [Mã SV], sv.HoTen AS [Họ tên], sv.NgaySinh AS [Ngày sinh], "
                + "sv.GioiTinh AS [Giới tính], sv.DiaChi AS [Địa chỉ], sv.SDT AS [SĐT], "
                + "l.TenLop AS [Lớp], sv.MaLop AS [Mã lớp] "
                + "FROM SinhVien sv JOIN Lop l ON sv.MaLop = l.MaLop "
                + "WHERE sv.MaSV LIKE ? OR sv.HoTen LIKE ? OR sv.SDT LIKE ? OR l.TenLop LIKE ? "
                + "ORDER BY sv.MaSV", k, k, k, k);
    }

    @Override
    protected void hienThiDong(int r) {
        txtMa.setText(cell(r, 0));
        txtTen.setText(cell(r, 1));
        txtNgaySinh.setText(cell(r, 2));
        cboGioiTinh.setSelectedItem(cell(r, 3));
        txtDiaChi.setText(cell(r, 4));
        txtSdt.setText(cell(r, 5));
        Db.select(cboLop, cell(r, 7));
    }

    @Override
    protected void lamMoi() {
        txtMa.setText("");
        txtTen.setText("");
        txtNgaySinh.setText("");
        cboGioiTinh.setSelectedIndex(0);
        txtDiaChi.setText("");
        txtSdt.setText("");
        if (cboLop.getItemCount() > 0) {
            cboLop.setSelectedIndex(0);
        }
        table.clearSelection();
    }

    private Date docNgaySinh() {
        return Date.valueOf(LocalDate.parse(bat(txtNgaySinh, "Ngày sinh")));
    }

    private String docSdt() {
        String s = bat(txtSdt, "Số điện thoại");
        if (!s.matches("\\d{9,11}")) {
            throw new IllegalArgumentException("Số điện thoại phải gồm 9 đến 11 chữ số.");
        }
        return s;
    }

    @Override
    protected void them() throws SQLException {
        Db.update("INSERT INTO SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, SDT, MaLop) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)",
                bat(txtMa, "Mã sinh viên"), bat(txtTen, "Họ tên"), docNgaySinh(),
                cboGioiTinh.getSelectedItem(), tuyChon(txtDiaChi), docSdt(), Db.idOf(cboLop));
    }

    @Override
    protected void sua() throws SQLException {
        int n = Db.update("UPDATE SinhVien SET HoTen = ?, NgaySinh = ?, GioiTinh = ?, "
                        + "DiaChi = ?, SDT = ?, MaLop = ? WHERE MaSV = ?",
                bat(txtTen, "Họ tên"), docNgaySinh(), cboGioiTinh.getSelectedItem(),
                tuyChon(txtDiaChi), docSdt(), Db.idOf(cboLop), bat(txtMa, "Mã sinh viên"));
        kiemTraCoDong(n, "sửa");
    }

    @Override
    protected String cauHoiXoa() {
        return "Xóa sinh viên này? Điểm của sinh viên cũng sẽ bị xóa theo.";
    }

    @Override
    protected void xoa() throws SQLException {
        String ma = bat(txtMa, "Mã sinh viên");
        Db.update("DELETE FROM Diem WHERE MaSV = ?", ma);
        int n = Db.update("DELETE FROM SinhVien WHERE MaSV = ?", ma);
        kiemTraCoDong(n, "xóa");
    }
}
