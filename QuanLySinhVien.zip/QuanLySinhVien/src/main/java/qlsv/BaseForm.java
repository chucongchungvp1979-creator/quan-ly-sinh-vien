package qlsv;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.DateTimeException;

/**
 * Khung chung cho các form quản lý: phần nhập liệu, ô tìm kiếm, bảng dữ liệu
 * và các nút Thêm / Sửa / Xóa / Làm mới.
 * Lớp con chỉ cần khai báo các ô nhập (addField) rồi gọi build() ở cuối constructor.
 */
public abstract class BaseForm extends JFrame {

    protected interface Act {
        void run() throws Exception;
    }

    protected final JTable table = new JTable();
    protected final JTextField txtTim = new JTextField(20);
    private final JPanel pnlInput = new JPanel(new GridBagLayout());
    private int hang = 0;

    protected BaseForm(String title, int rong, int cao) {
        super(title);
        setSize(rong, cao);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    // ---------- Các hàm lớp con phải viết ----------
    /** Trả về dữ liệu hiển thị trên bảng, lọc theo từ khóa tìm kiếm. */
    protected abstract DefaultTableModel layDuLieu(String tuKhoa) throws SQLException;

    /** Đổ dữ liệu của dòng được chọn trên bảng lên các ô nhập. */
    protected abstract void hienThiDong(int dong);

    /** Xóa trắng các ô nhập. */
    protected abstract void lamMoi();

    protected abstract void them() throws SQLException;

    protected abstract void sua() throws SQLException;

    protected abstract void xoa() throws SQLException;

    protected String cauHoiXoa() {
        return "Bạn có chắc chắn muốn xóa bản ghi này?";
    }

    // ---------- Dựng giao diện ----------
    protected void addField(String nhan, JComponent o) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);
        g.gridy = hang++;
        g.gridx = 0;
        g.anchor = GridBagConstraints.WEST;
        pnlInput.add(new JLabel(nhan), g);
        g.gridx = 1;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        pnlInput.add(o, g);
    }

    /** Gọi ở cuối constructor của lớp con, sau khi đã addField xong. */
    protected void build() {
        setLayout(new BorderLayout(8, 8));

        pnlInput.setBorder(BorderFactory.createTitledBorder("Thông tin"));
        add(pnlInput, BorderLayout.NORTH);

        // Khu vực giữa: ô tìm kiếm + bảng
        JPanel pnlGiua = new JPanel(new BorderLayout(4, 4));
        JPanel pnlTim = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnTim = new JButton("Tìm kiếm");
        pnlTim.add(new JLabel("Từ khóa:"));
        pnlTim.add(txtTim);
        pnlTim.add(btnTim);
        pnlGiua.add(pnlTim, BorderLayout.NORTH);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(24);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                hienThiDong(table.getSelectedRow());
            }
        });
        pnlGiua.add(new JScrollPane(table), BorderLayout.CENTER);
        add(pnlGiua, BorderLayout.CENTER);

        // Hàng nút chức năng
        JPanel pnlNut = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnMoi = new JButton("Làm mới");
        pnlNut.add(btnThem);
        pnlNut.add(btnSua);
        pnlNut.add(btnXoa);
        pnlNut.add(btnMoi);
        add(pnlNut, BorderLayout.SOUTH);

        btnThem.addActionListener(e -> chay(this::them, "Thêm thành công!"));
        btnSua.addActionListener(e -> chay(this::sua, "Cập nhật thành công!"));
        btnXoa.addActionListener(e -> {
            int kq = JOptionPane.showConfirmDialog(this, cauHoiXoa(), "Xác nhận xóa",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (kq == JOptionPane.YES_OPTION) {
                chay(this::xoa, "Đã xóa!");
            }
        });
        btnMoi.addActionListener(e -> {
            txtTim.setText("");
            lamMoi();
            napBang();
        });
        btnTim.addActionListener(e -> napBang());
        txtTim.addActionListener(e -> napBang());

        napBang();
    }

    // ---------- Xử lý chung ----------
    protected void napBang() {
        try {
            table.setModel(layDuLieu(txtTim.getText().trim()));
        } catch (SQLException ex) {
            loi(ex);
        }
    }

    private void chay(Act a, String thongBao) {
        try {
            a.run();
            napBang();
            lamMoi();
            JOptionPane.showMessageDialog(this, thongBao);
        } catch (NumberFormatException ex) {
            canhBao("Giá trị nhập vào phải là số hợp lệ.");
        } catch (IllegalArgumentException ex) {
            canhBao(ex.getMessage());
        } catch (DateTimeException ex) {
            canhBao("Ngày không hợp lệ. Hãy nhập theo dạng yyyy-MM-dd, ví dụ 2005-03-12.");
        } catch (SQLException ex) {
            loi(ex);
        } catch (Exception ex) {
            canhBao(ex.toString());
        }
    }

    protected void canhBao(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Thông báo", JOptionPane.WARNING_MESSAGE);
    }

    protected void loi(SQLException ex) {
        String msg;
        switch (ex.getErrorCode()) {
            case 2627:
            case 2601:
                msg = "Dữ liệu bị trùng (mã hoặc số điện thoại đã tồn tại).";
                break;
            case 547:
                msg = "Vi phạm ràng buộc dữ liệu: bản ghi đang được dùng ở bảng khác,"
                        + "\nhoặc giá trị không hợp lệ (ví dụ điểm ngoài khoảng 0 - 10).";
                break;
            default:
                msg = ex.getMessage();
        }
        JOptionPane.showMessageDialog(this, msg, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    /** Lấy chuỗi bắt buộc nhập, ném lỗi nếu để trống. */
    protected String bat(JTextField t, String ten) {
        String s = t.getText().trim();
        if (s.isEmpty()) {
            throw new IllegalArgumentException(ten + " không được để trống.");
        }
        return s;
    }

    /** Lấy chuỗi không bắt buộc, trả về null nếu để trống. */
    protected String tuyChon(JTextField t) {
        String s = t.getText().trim();
        return s.isEmpty() ? null : s;
    }

    /** Giá trị ô (dòng, cột) của bảng dưới dạng chuỗi, null được đổi thành chuỗi rỗng. */
    protected String cell(int dong, int cot) {
        Object o = table.getValueAt(dong, cot);
        return o == null ? "" : o.toString();
    }

    protected void kiemTraCoDong(int soDong, String viec) {
        if (soDong == 0) {
            throw new IllegalArgumentException(
                    "Không tìm thấy bản ghi để " + viec + ". Hãy chọn một dòng trong bảng.");
        }
    }
}
