package qlsv;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;

/** Form: Quản lý khoa. */
public class KhoaForm extends BaseForm {
    private final JTextField txtMa = new JTextField();
    private final JTextField txtTen = new JTextField();

    public KhoaForm() {
        super("Quản lý khoa", 650, 500);
        addField("Mã khoa:", txtMa);
        addField("Tên khoa:", txtTen);
        build();
    }

    @Override
    protected DefaultTableModel layDuLieu(String kw) throws SQLException {
        String k = "%" + kw + "%";
        return Db.query("SELECT MaKhoa AS [Mã khoa], TenKhoa AS [Tên khoa] FROM Khoa "
                + "WHERE MaKhoa LIKE ? OR TenKhoa LIKE ? ORDER BY MaKhoa", k, k);
    }

    @Override
    protected void hienThiDong(int r) {
        txtMa.setText(cell(r, 0));
        txtTen.setText(cell(r, 1));
    }

    @Override
    protected void lamMoi() {
        txtMa.setText("");
        txtTen.setText("");
        table.clearSelection();
    }

    @Override
    protected void them() throws SQLException {
        Db.update("INSERT INTO Khoa(MaKhoa, TenKhoa) VALUES (?, ?)",
                bat(txtMa, "Mã khoa"), bat(txtTen, "Tên khoa"));
    }

    @Override
    protected void sua() throws SQLException {
        int n = Db.update("UPDATE Khoa SET TenKhoa = ? WHERE MaKhoa = ?",
                bat(txtTen, "Tên khoa"), bat(txtMa, "Mã khoa"));
        kiemTraCoDong(n, "sửa");
    }

    @Override
    protected void xoa() throws SQLException {
        int n = Db.update("DELETE FROM Khoa WHERE MaKhoa = ?", bat(txtMa, "Mã khoa"));
        kiemTraCoDong(n, "xóa");
    }
}
