package qlsv;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;

/** Form: Quản lý môn học. */
public class MonHocForm extends BaseForm {
    private final JTextField txtMa = new JTextField();
    private final JTextField txtTen = new JTextField();
    private final JTextField txtTinChi = new JTextField();

    public MonHocForm() {
        super("Quản lý môn học", 700, 520);
        addField("Mã môn học:", txtMa);
        addField("Tên môn học:", txtTen);
        addField("Số tín chỉ (1 - 10):", txtTinChi);
        build();
    }

    @Override
    protected DefaultTableModel layDuLieu(String kw) throws SQLException {
        String k = "%" + kw + "%";
        return Db.query("SELECT MaMH AS [Mã MH], TenMH AS [Tên môn học], SoTinChi AS [Số tín chỉ] "
                + "FROM MonHoc WHERE MaMH LIKE ? OR TenMH LIKE ? ORDER BY MaMH", k, k);
    }

    @Override
    protected void hienThiDong(int r) {
        txtMa.setText(cell(r, 0));
        txtTen.setText(cell(r, 1));
        txtTinChi.setText(cell(r, 2));
    }

    @Override
    protected void lamMoi() {
        txtMa.setText("");
        txtTen.setText("");
        txtTinChi.setText("");
        table.clearSelection();
    }

    private int docTinChi() {
        int tc = Integer.parseInt(bat(txtTinChi, "Số tín chỉ"));
        if (tc < 1 || tc > 10) {
            throw new IllegalArgumentException("Số tín chỉ phải từ 1 đến 10.");
        }
        return tc;
    }

    @Override
    protected void them() throws SQLException {
        Db.update("INSERT INTO MonHoc(MaMH, TenMH, SoTinChi) VALUES (?, ?, ?)",
                bat(txtMa, "Mã môn học"), bat(txtTen, "Tên môn học"), docTinChi());
    }

    @Override
    protected void sua() throws SQLException {
        int n = Db.update("UPDATE MonHoc SET TenMH = ?, SoTinChi = ? WHERE MaMH = ?",
                bat(txtTen, "Tên môn học"), docTinChi(), bat(txtMa, "Mã môn học"));
        kiemTraCoDong(n, "sửa");
    }

    @Override
    protected void xoa() throws SQLException {
        int n = Db.update("DELETE FROM MonHoc WHERE MaMH = ?", bat(txtMa, "Mã môn học"));
        kiemTraCoDong(n, "xóa");
    }
}
