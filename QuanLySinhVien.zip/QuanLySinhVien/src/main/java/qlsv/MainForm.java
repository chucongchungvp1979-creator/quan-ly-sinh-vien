package qlsv;

import javax.swing.*;
import java.awt.*;
import java.util.function.Supplier;

/** Form 1: Màn hình chính (menu). */
public class MainForm extends JFrame {

    public MainForm() {
        super("Phần mềm quản lý sinh viên");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(420, 460);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel lbl = new JLabel("QUẢN LÝ SINH VIÊN", SwingConstants.CENTER);
        lbl.setFont(lbl.getFont().deriveFont(Font.BOLD, 24f));
        lbl.setBorder(BorderFactory.createEmptyBorder(24, 10, 10, 10));
        add(lbl, BorderLayout.NORTH);

        JPanel pnl = new JPanel(new GridLayout(0, 1, 10, 10));
        pnl.setBorder(BorderFactory.createEmptyBorder(10, 40, 30, 40));
        pnl.add(nut("Quản lý sinh viên", SinhVienForm::new));
        pnl.add(nut("Quản lý lớp", LopForm::new));
        pnl.add(nut("Quản lý khoa", KhoaForm::new));
        pnl.add(nut("Quản lý môn học", MonHocForm::new));
        pnl.add(nut("Quản lý điểm", DiemForm::new));

        JButton btnThoat = new JButton("Thoát");
        btnThoat.addActionListener(e -> System.exit(0));
        pnl.add(btnThoat);
        add(pnl, BorderLayout.CENTER);
    }

    private JButton nut(String text, Supplier<JFrame> form) {
        JButton b = new JButton(text);
        b.addActionListener(e -> form.get().setVisible(true));
        return b;
    }
}
