package qlsv;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.sql.Connection;
import java.sql.SQLException;

/** Điểm khởi chạy của chương trình. */
public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // dùng giao diện mặc định nếu không đặt được
        }
        SwingUtilities.invokeLater(() -> {
            try (Connection c = Db.getConnection()) {
                new MainForm().setVisible(true);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null,
                        "Không kết nối được SQL Server:\n" + ex.getMessage()
                                + "\n\nHãy kiểm tra: SQL Server đã chạy, đã tạo CSDL QuanLySinhVien,"
                                + "\nvà cấu hình HOST/PORT/USER/PASSWORD trong file Db.java.",
                        "Lỗi kết nối", JOptionPane.ERROR_MESSAGE);
                System.exit(1);
            }
        });
    }
}
